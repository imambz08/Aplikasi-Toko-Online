
    <script type="text/javascript">
        setTimeout(function(){
            document.getElementById('myimage').style.display = 'block';
        },6000);
    </script>

    <!-- Footer -->
    <footer class="footer-area p-t-20 p-b-20">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="footer-widget-area">
                        <p class="copywrite-text">
                            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved. Developed by Solo Radio
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- Popper js -->
    <script src="<?php echo base_url("assets/themev2/js/bootstrap/popper.min.js"); ?>"></script>
    <!-- Bootstrap js -->
    <script src="<?php echo base_url("assets/themev2/js/bootstrap/bootstrap.min.js"); ?>"></script>
    <!-- All Plugins js -->
    <script src="<?php echo base_url("assets/themev2/js/plugins/plugins.js"); ?>"></script>
    <!-- Active js -->
    <script src="<?php echo base_url("assets/themev2/js/active.js"); ?>"></script>
    <script src="<?php echo base_url("assets/js/jquery-sortable.js"); ?>"></script>
</body>

</html>