<div class="section-padding-150-0">
	<div class="container m-b-100">
		<div class="nf-section">
			<h1>404</h1>
			Mohon maaf, halaman yang Anda cari tidak ditemukan. Silahkan kembali ke 
			<a href="javascript:history.back()">halaman sebelumnya</a> atau ke
			<a href="<?=site_url()?>">beranda</a>
		</div>
	</div>
</div>